<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ejercicio 7</title>
</head>
<body>
    <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
        
        <label for="n">codigo: </label>
        <input type="text" name="codigo">

        <label for="n">numero de hijos: </label>
        <input type="text" name="numerohijos">

        <label for="n">Nombre: </label>
        <input type="text" name="nombre">
        
        <label for="n">salario: </label>
        <input type="text" name="salario">

        <label for="n">horas de trabajo: </label>
        <input type="text" name="horas">

        <input type="submit" value="enviar">
    </form>
    
</body>
</html>
<?php
    if (!empty($_POST['codigo']) && !empty($_POST['nombre']) && !empty($_POST['salario']) && !empty($_POST['horas']) && !empty($_POST['numerohijos'])) {
        $hijos = $_POST['numerohijos'];
        $salario = $_POST['salario'];
        $horas = $_POST['horas'];

        if ($salario < 580000) {
            if ($hijos > 6) {
                echo "no hay retencion";
                
            }else{
                $porsentaje = (6 - $hijos) / 2;
                $salario = $salario * $porsentaje;
                echo "se hara una retencion de un " . round($porsentaje). " % la cantidad serad de: " . round($salario);
            }
        }elseif ($salario >= 580000) {
            if ($hijos < 3) {
                $porsentaje = 0.3;
            }else{
                $porsentaje = 10 / $hijos;
            }
        }
        $subsidio = $hijos * 1200;
        $salario = $salario * $porsentaje;
        echo "se hara una retencion de un " . round($porsentaje). " % la cantidad serad de: " . round($salario) ."<br>";
        echo "el subsidio todal es de: $subsidio";
    }

?>