<?php 
    $i = 50;
    while ($i >= 40) {
        echo "$i <br>";
        $i--;
    }
?>