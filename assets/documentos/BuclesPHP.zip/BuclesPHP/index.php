<?php 
    for ($i=50; $i >= 40; $i--) { 
        echo " $i <br> ";
    }

    echo "---------ejercicio b del trabajo 3--------------- <br>" ;

    $b = 1;
    for ($i=0; $i < 5 ; $i++) { 
        $contador = $b * 2;
        echo $contador . '<br>';
        $b++;
    }
?>