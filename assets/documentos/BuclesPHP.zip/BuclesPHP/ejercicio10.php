<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ejercicio 9</title>
</head>
<body>
    <form action="ejercicio10_b.php" method="post">

        <label for="nota1">nota 1:</label>
        <input type="number" name="nota1">

        <label for="creditos1">creditos 1:</label>
        <input type="number" name="creditos1">

        <label for="nota2">nota 2:</label>
        <input type="number" name="nota2">

        <label for="creditos2">creditos 2:</label>
        <input type="number" name="creditos2">

        <label for="nota3">nota 3:</label>
        <input type="number" name="nota3">

        <label for="creditos3">creditos 3:</label>
        <input type="number" name="creditos3">

        <label for="nota4">nota 4:</label>
        <input type="number" name="nota4">

        <label for="creditos4">creditos 4:</label>
        <input type="number" name="creditos4">


        <label for="nota5">nota 5:</label>
        <input type="number" name="nota5">

        <label for="creditos5">creditos 5:</label>
        <input type="number" name="creditos5">


        <label for="nota6">nota 6:</label>
        <input type="number" name="nota6">

        <label for="creditos6">creditos 6:</label>
        <input type="number" name="creditos6">

        <label for="nota7">nota 7:</label>
        <input type="number" name="nota7">

        <label for="creditos7">creditos 7:</label>
        <input type="number" name="creditos7">

        <label for="nota8">nota 8:</label>
        <input type="number" name="nota8">

        <label for="creditos8">creditos 8:</label>
        <input type="number" name="creditos8">

        <label for="nota9">nota 9:</label>
        <input type="number" name="nota9">

        <label for="creditos9">creditos 9:</label>
        <input type="number" name="creditos9">

        <label for="nota10">nota 10:</label>
        <input type="number" name="nota10">

        <label for="creditos10">creditos 10:</label>
        <input type="number" name="creditos10">

        <input type="submit" value="enviar">

    </form>

    
    
</body>
</html>