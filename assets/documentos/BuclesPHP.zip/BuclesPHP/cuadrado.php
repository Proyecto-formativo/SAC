<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>cuadrado</title>
</head>
<body>
    <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
        <label for="numero">numero:</label>
        <input type="text" name="num">
        <input type="submit" value="enviar">
    </form>

    <?php 
    if (!empty($_POST['num'])) {
       $num = $_POST['num'];
    ?>
       <table border='1'>
    <?php
       for ($i=0; $i < $num ; $i++) { 
           $aux = 1;
           $con = $i+1;
        ?>
           <tr> <td> <?=$con ?> </td>
        <?php    
           $nu = 1;
            $value = $con * $con;
        ?>
           <td> <?=$value ?></td> <td>
        <?php
           while ($aux <= $con) {
                echo $nu;
                $nu += 2; 
                if ($aux < $con ) {

                    echo "+";
               }else{
        ?>
                </td>
        <?php
               }
               $aux++;
           }
           ?>
            </tr>
        <?php   
       }    
       ?>
      </table>
      <?php
    }

    ?>
</body>
</html>