<?php 
    error_reporting(0);
    $i = 1;
    $creditos = 0;
    $notas = 0;
    while($i <= 4):
        $notas += $_POST['nota'.$i];
        $creditos += $_POST['creditos'.$i];
        $i++;
    endwhile;
    $notas = $notas / 4.0;
    if ($notas > 45) {
        echo 'recibira un descuento <br>'; 
    }
    echo "total: $notas <br>";
    echo "total creditos: $creditos";
       
    ?>