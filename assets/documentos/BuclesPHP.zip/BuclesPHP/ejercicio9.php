<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ejercicio 9</title>
</head>
<body>
    <form action="" method="post">

        <label for="tipoventa">tipo de venta:</label>
        <select name="valor" id="tipoventa">
            <option value="1">1:contado</option>
            <option value="2">2:cheque</option>
            <option value="3">3:tarjeta</option>    
        </select>


        <label for="codigo">Codigo del vendedor:</label>
        <select name="vendedor" id="codigo">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
        </select>

        

        <label for="cantidad">precio total:</label>
        <input type="number" name="cantidad">

        <input type="submit" value="enviar">

    </form>

    <?php 
        session_start();
    
        if (!empty($_POST['vendedor']) && !empty($_POST['valor'])  && !empty($_POST['cantidad'])) {
            $vendedor = $_POST['vendedor'];
            $valor = $_POST['valor'];
            $cantidad = $_POST['cantidad'];
            switch ($valor) {
                case 1:
                    $comision = $cantidad * 0.15;
                    break;
                case 2:
                    $comision = $cantidad * 0.10;
                    break;
                case 3:
                    $comision = $cantidad * 0.05;
                    break;  
            }


           switch ($vendedor) {
               case 1:
                   $_SESSION['valor1'] += $comision;
                   break;
                case 2:
                   $_SESSION['valor2'] += $comision;
                   break;
                case 3:
                   $_SESSION['valor3'] += $comision;
                   break;
                case 4:
                   $_SESSION['valor4'] += $comision;
                   break;
                case 5:
                   $_SESSION['valor5'] += $comision;
                   break;
                case 6:
                   $_SESSION['valor6'] += $comision;
                   break;
                case 7:
                   $_SESSION['valor7'] += $comision;
                   break;
                case 8:
                   $_SESSION['valor8'] += $comision;
                   break;
                case 9:
                   $_SESSION['valor9'] += $comision;
                   break;
                case 10:
                   $_SESSION['valor10'] += $comision;
                   break;
               
               
           }
        }
        $i = 1;
        $table = '<table border=1>';
        while($i < 11):
            $table .= '<tr> <td> vendedor:'.$i.' </td> <td>'.$_SESSION['valor' .$i] .' </td> </tr>';
            $i++;
        endwhile;
        $table .= '</table>';
        print($table);
    ?>
    
</body>
</html>