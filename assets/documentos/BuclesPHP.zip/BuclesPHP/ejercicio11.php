<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ejercicio 11</title>
</head>
<body>

    <form action="#" method="POST">
        <label for="num">Digite el número: </label>
        <input type="text" name="num" max="1000">
        <input type="submit">
    </form>
    
</body>
</html>

<?php
    if (isset($_POST['num'])) {
        $num = $_POST['num'];
        if ($num < 0) {
            $cubo = $num * $num * $num;
           echo "El número es menor de 0, el cubo de $num es: $cubo"; 
        } elseif ($num > 0 && $num < 100) {
            $cuadrado = $num * $num;
            echo "El número esta entre 0 y 100, el cubo de $num es: $cuadrado"; 
        } else {
            $raiz = ($num * $num) / ($num * 12);
            echo "La raiz cuadrada es: $raiz";
        }
        
    }
?>