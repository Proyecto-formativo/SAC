<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ejercicio 8</title>
</head>
<body>

    <form action="#" method="POST">
        <label for="anio">Año de nacimiento</label>
        <input type="text" name="anio">
        <br>
        <br>
        <label for="sexo">Sexo: </label>
        <select name="sexo" id="">
            <option value="Masculino">Masculino</option>
            <option value="Femenino">Femenino</option>
        </select>
        <br>
        <br>
        <label for="ciudad">Registro: </label>
        <select name="ciudad" id="">
            <option value="Medellin">Medellin</option>
            <option value="Otras">Otras Ciudades</option>
        </select>
        <input type="submit">
    </form>
    <br>
    <br>
    
</body>
</html>

<?php 
    if (isset($_POST['anio']) && isset($_POST['sexo']) && isset($_POST['ciudad'])) {
        $anio = $_POST['anio'];
        $sexo = $_POST['sexo'];
        $ciudad = $_POST['ciudad'];
        if ((2019 - $anio) < 25) {
            $edad = 2019 - $anio;
            echo "El conductor es menor de 25 años, la edad del conductor es: $edad <br>";
        }
        if ($sexo == 'Masculino') {
            echo 'el conductor es de sexo Masculino <br>';
        } else {
            echo 'el conductor es de sexo femenino <br>';
        }
        if ($ciudad == 'Medellin') {
            echo 'El vehiculo fue registrado en Medellin';
        } else {
            echo 'El vehiculo fue registrado en otra ciudad';
        }
    }
?>