<?php
    for ($i=100; $i <= 500; $i+= 100) { 
        $resultado = $i / 20;
        echo "$resultado <br>";
    }
?>