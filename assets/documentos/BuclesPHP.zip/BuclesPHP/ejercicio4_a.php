<?php
    for ($i=50; $i <= 500; $i += 25) { 
        echo "$i <br>";
    }
?>