<?php
    $contador = 1;
    while ($contador <= 5) {
        $doble = $contador * 2;
        echo "$doble <br>";
        $contador++;
    }
?>